# Sitam_Uniform_Detection1 > dataset
https://universe.roboflow.com/sridhar-sanapala-4tunp/sitam_uniform_detection1-atpmi

Provided by a Roboflow user
License: CC BY 4.0

